---
title: Khắc phục lỗi Office phổ biến
slug: khac-phuc-loi-office
date: 2025-10-24
---
# Khắc phục lỗi Office phổ biến

- Sửa lỗi *Product Activation Failed*: đăng nhập tài khoản bản quyền, kiểm tra **Licensing Service**.
- Lỗi cài đặt *0x80070005*: chạy `sfc /scannow`, tắt antivirus tạm thời, dùng *Microsoft Support and Recovery Assistant (SaRA)*.
