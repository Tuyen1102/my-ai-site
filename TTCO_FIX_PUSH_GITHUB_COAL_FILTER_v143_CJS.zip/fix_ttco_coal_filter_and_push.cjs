// TTCO fix v1.4.2 - lọc chủng loại than theo tồn kho hiện hành.
// Chạy tại thư mục gốc repo my-ai-site: node fix_ttco_coal_filter_and_push.js
const fs = require('fs');
const path = require('path');

const appPath = path.join(process.cwd(), 'src', 'App.jsx');
if (!fs.existsSync(appPath)) {
  console.error('[LOI] Không tìm thấy src/App.jsx. Hãy chạy tại thư mục gốc repo my-ai-site.');
  process.exit(1);
}

let code = fs.readFileSync(appPath, 'utf8');
const originalCode = code;
const backupPath = appPath + `.bak_${new Date().toISOString().replace(/[:.]/g, '-')}`;
fs.writeFileSync(backupPath, code, 'utf8');

const helperBlock = `
// Fix v1.4.2: Lọc dữ liệu tồn kho hiện hành trước khi dựng danh sách chủng loại.
// Không hard-code Kho 26/Kho 28; kho nào có chủng loại tồn thực tế > 0 thì tự hiện.
const stripVietnameseMarks = (value) =>
  normalizeKey(value)
    .normalize("NFD")
    .replace(/[\\u0300-\\u036f]/g, "")
    .replace(/đ/g, "d")
    .replace(/Đ/g, "d");

const looksLikeSpecificCoalProductName = (value) => {
  const key = stripVietnameseMarks(normalizeCoalBase(value));
  if (!key) return false;
  return (
    key.startsWith("cam ") ||
    key.startsWith("cuc ") ||
    key.startsWith("bun ") ||
    key.startsWith("da ") ||
    key.startsWith("nguyen khai") ||
    key.startsWith("ba ") ||
    key.includes(" ntc")
  );
};

const isGenericTtcoCoalGroupName = (value) => {
  const key = stripVietnameseMarks(normalizeCoalBase(value));
  if (!key) return true;
  return (
    key === "than nk" ||
    key === "than nhk" ||
    key === "than nhap khau" ||
    key.startsWith("than anthracite")
  );
};

const isValidCurrentTtcoStockRecord = (record) => {
  if (!record) return false;
  if (!getStandardKhoInfo(record.khoCode || record.kho)) return false;
  const coalName = normalizeText(record.coal);
  if (!coalName) return false;
  if (toNumber(record.ton) <= 0) return false;

  // Loại dòng nhóm/tên nguồn nhập khẩu chung; vẫn giữ các chủng loại cụ thể như Cám 6b.1, Cám 6a.14...
  if (isGenericTtcoCoalGroupName(coalName) && !looksLikeSpecificCoalProductName(coalName)) {
    return false;
  }

  return true;
};
`;

function replaceOnce(searchValue, replaceValue, label) {
  if (code.includes(replaceValue)) return false;
  if (!code.includes(searchValue)) return false;
  code = code.replace(searchValue, replaceValue);
  console.log('[OK]', label);
  return true;
}

if (!code.includes('const isValidCurrentTtcoStockRecord =')) {
  const marker = 'const getTtcoCoalTypesForWarehouse = (warehouse, ttcoRecords, coalTypes) => {';
  if (!code.includes(marker)) {
    console.error('[LOI] Không tìm thấy hàm getTtcoCoalTypesForWarehouse để chèn bộ lọc.');
    process.exit(1);
  }
  code = code.replace(marker, helperBlock + '\n' + marker);
  console.log('[OK] Đã chèn bộ lọc dữ liệu tồn kho hợp lệ');
} else {
  console.log('[BO QUA] Bộ lọc đã tồn tại trong App.jsx');
}

const patches = [
  {
    label: 'Lọc dữ liệu JSON trước khi gộp bản ghi',
    from: '.filter((item) => item?.khoCode && item.coal); const recordMap = new Map();',
    to: '.filter((item) => item?.khoCode && item.coal) .filter(isValidCurrentTtcoStockRecord); const recordMap = new Map();',
  },
  {
    label: 'Lọc dữ liệu JSON trước khi gộp bản ghi',
    from: '.filter((item) => item?.khoCode && item.coal);\n  const recordMap = new Map();',
    to: '.filter((item) => item?.khoCode && item.coal)\n    .filter(isValidCurrentTtcoStockRecord);\n  const recordMap = new Map();',
  },
  {
    label: 'Bảo vệ dropdown loại than',
    from: 'for (const item of ttcoRecords) { const itemCode = getKhoCompareCode(item.khoCode || item.kho);',
    to: 'for (const item of ttcoRecords) { if (!isValidCurrentTtcoStockRecord(item)) continue; const itemCode = getKhoCompareCode(item.khoCode || item.kho);',
  },
  {
    label: 'Bảo vệ dropdown loại than',
    from: 'for (const item of ttcoRecords) {\n    const itemCode = getKhoCompareCode(item.khoCode || item.kho);',
    to: 'for (const item of ttcoRecords) {\n    if (!isValidCurrentTtcoStockRecord(item)) continue;\n    const itemCode = getKhoCompareCode(item.khoCode || item.kho);',
  },
  {
    label: 'Bảo vệ danh sách kho',
    from: 'for (const record of ttcoRecords) { const standardKho = getStandardKhoInfo(record.khoCode) || getStandardKhoInfo(record.kho);',
    to: 'for (const record of ttcoRecords) { if (!isValidCurrentTtcoStockRecord(record)) continue; const standardKho = getStandardKhoInfo(record.khoCode) || getStandardKhoInfo(record.kho);',
  },
  {
    label: 'Bảo vệ danh sách kho',
    from: 'for (const record of ttcoRecords) {\n    const standardKho = getStandardKhoInfo(record.khoCode) || getStandardKhoInfo(record.kho);',
    to: 'for (const record of ttcoRecords) {\n    if (!isValidCurrentTtcoStockRecord(record)) continue;\n    const standardKho = getStandardKhoInfo(record.khoCode) || getStandardKhoInfo(record.kho);',
  },
  {
    label: 'Bảo vệ khối lượng TTCO_APP tự điền',
    from: 'const matched = ttcoRecords.filter((item) => { const itemCode = getKhoCompareCode(item.khoCode || item.kho);',
    to: 'const matched = ttcoRecords.filter((item) => { if (!isValidCurrentTtcoStockRecord(item)) return false; const itemCode = getKhoCompareCode(item.khoCode || item.kho);',
  },
  {
    label: 'Bảo vệ khối lượng TTCO_APP tự điền',
    from: 'const matched = ttcoRecords.filter((item) => {\n    const itemCode = getKhoCompareCode(item.khoCode || item.kho);',
    to: 'const matched = ttcoRecords.filter((item) => {\n    if (!isValidCurrentTtcoStockRecord(item)) return false;\n    const itemCode = getKhoCompareCode(item.khoCode || item.kho);',
  },
];

let changedPatches = 0;
for (const p of patches) {
  if (replaceOnce(p.from, p.to, p.label)) changedPatches += 1;
}

if (code === originalCode) {
  console.log('[THONG BAO] App.jsx không thay đổi. Có thể file đã được sửa từ trước.');
} else {
  fs.writeFileSync(appPath, code, 'utf8');
  console.log('[OK] Đã ghi src/App.jsx');
}
console.log('[OK] Backup:', backupPath);
